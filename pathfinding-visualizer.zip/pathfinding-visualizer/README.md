# Pathfinding Visualizer

An interactive web app that visualizes pathfinding algorithms on a grid. You define the **start**, the **end** and the **obstacles**, then watch the algorithm search.

- **Algorithms:** A*, Dijkstra, Breadth-First Search, Depth-First Search, Greedy Best-First
- **Options:** Manhattan / Euclidean / Chebyshev heuristics, diagonal moves (no corner cutting), speed control, random obstacles
- **Stats:** nodes explored, path length, path cost, status (including "No path")

Plain HTML + CSS + JavaScript. No build step, no dependencies.

## Run in VS Code

1. Open this folder in VS Code (`File > Open Folder`).
2. Install the **Live Server** extension (VS Code will suggest it).
3. Right-click `index.html` and choose **Open with Live Server**.

Alternatives: double-click `index.html`, or run `npm start` (needs Node.js).

## Run the tests

```bash
npm test
```

## Push to GitHub

Create an empty repository on github.com first (no README or license), then:

```bash
git init
git add .
git commit -m "Pathfinding visualizer"
git branch -M main
git remote add origin https://github.com/<your-username>/pathfinding-visualizer.git
git push -u origin main
```

### Free hosting with GitHub Pages
Repo **Settings > Pages > Source: GitHub Actions**. The included workflow (`.github/workflows/pages.yml`) publishes the site at `https://<your-username>.github.io/pathfinding-visualizer/` on every push to `main`.

## Project structure

```
index.html            page layout
css/style.css         styles (light + dark mode)
js/algorithms.js      pure pathfinding logic (testable, no DOM)
js/app.js             canvas drawing, interaction, animation
tests/                unit tests (node --test)
docs/PRESENTATION.md  class presentation outline
```

## How it works

`Pathfinding.search()` is a generator: every `yield` is one node expansion `{ closed, opened[] }`. The UI pulls events at the chosen speed and colors the grid, which gives the step-by-step animation.

| Algorithm | Open list | Optimal? |
|---|---|---|
| BFS | queue | yes (in steps) |
| DFS | stack | no |
| Dijkstra | lowest g | yes |
| A* | lowest g + h | yes (admissible h) |
| Greedy | lowest h | no |

## License
MIT
