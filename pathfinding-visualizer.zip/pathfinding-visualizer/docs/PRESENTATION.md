# Presentation Outline (about 10 minutes)

1. **Problem** - shortest path on a grid with user-defined start, end and obstacles.
2. **Model** - grid = graph; each free cell is a node; edges to 4 (or 8) neighbours; cost 1 (diagonal sqrt 2).
3. **Algorithms** - BFS (queue), DFS (stack), Dijkstra (lowest g), A* (g + h), Greedy (h only).
4. **Live demo**
   - A* with a few obstacles, then Dijkstra on the same map: compare *nodes explored*.
   - DFS: path found but not shortest.
   - Greedy with a U-shaped wall: not optimal.
   - Wall off the end: "No path".
   - Toggle diagonal moves and heuristics.
5. **Implementation** - `js/algorithms.js` (pure logic, a generator yields one expansion per step),
   `js/app.js` (canvas, pointer events, animation loop), unit tests in `tests/`.
6. **Complexity** - BFS O(V+E); Dijkstra/A* O((V+E) log V) with a heap (this project uses a linear scan for clarity).
7. **Future work** - weighted cells, maze generation, bidirectional search, Jump Point Search.
