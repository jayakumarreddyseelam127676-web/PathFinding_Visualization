/**
 * Pure pathfinding logic (no DOM). Works in the browser (window.Pathfinding)
 * and in Node (module.exports) so it can be unit-tested.
 * Grid cells are stored in a flat array: index = y * cols + x.
 */
(function (global) {
  'use strict';
  const SQRT2 = Math.SQRT2;

  function neighbors(i, cols, rows, walls, diagonal) {
    const x = i % cols, y = (i / cols) | 0, out = [];
    const free = (a, b) => a >= 0 && b >= 0 && a < cols && b < rows && !walls[b * cols + a];
    for (const [dx, dy] of [[0, -1], [1, 0], [0, 1], [-1, 0]])
      if (free(x + dx, y + dy)) out.push([(y + dy) * cols + x + dx, 1]);
    if (diagonal)
      for (const [dx, dy] of [[1, -1], [1, 1], [-1, 1], [-1, -1]])
        // no corner cutting: both orthogonal neighbours must be free
        if (free(x + dx, y + dy) && free(x + dx, y) && free(x, y + dy))
          out.push([(y + dy) * cols + x + dx, SQRT2]);
    return out;
  }

  function heuristic(type, i, goal, cols) {
    const dx = Math.abs((i % cols) - (goal % cols));
    const dy = Math.abs(((i / cols) | 0) - ((goal / cols) | 0));
    if (type === 'euclid') return Math.hypot(dx, dy);
    if (type === 'cheb') return Math.max(dx, dy);
    return dx + dy; // manhattan
  }

  /**
   * Generator: each step yields { closed, opened[] } (one node expansion).
   * Returns { found, prev } when finished.
   * opts: { algo, cols, rows, walls, start, end, diagonal, heuristic }
   * algo: 'bfs' | 'dfs' | 'dijkstra' | 'astar' | 'greedy'
   */
  function* search(opts) {
    const { algo, cols, rows, walls, start, end, diagonal } = opts;
    const n = cols * rows;
    const dist = new Float64Array(n).fill(Infinity);
    const closed = new Uint8Array(n), disc = new Uint8Array(n);
    const prev = new Int32Array(n).fill(-1);
    const open = [start];
    dist[start] = 0; disc[start] = 1;
    const h = (i) => heuristic(opts.heuristic || 'manhattan', i, end, cols);
    const key = (i) => algo === 'dijkstra' ? dist[i] : algo === 'astar' ? dist[i] + h(i) : h(i);

    while (open.length) {
      let cur;
      if (algo === 'bfs') cur = open.shift();            // queue
      else if (algo === 'dfs') cur = open.pop();         // stack
      else {                                             // priority queue (linear scan)
        let b = 0, bk = Infinity;
        for (let k = 0; k < open.length; k++) { const kk = key(open[k]); if (kk < bk) { bk = kk; b = k; } }
        cur = open.splice(b, 1)[0];
      }
      if (closed[cur]) continue;
      closed[cur] = 1;
      if (cur === end) { yield { closed: cur, opened: [] }; return { found: true, prev }; }

      const opened = [];
      for (const [nb, w] of neighbors(cur, cols, rows, walls, diagonal)) {
        if (closed[nb]) continue;
        const nd = dist[cur] + w;
        if (algo === 'bfs') {
          if (disc[nb]) continue;
          disc[nb] = 1; dist[nb] = nd; prev[nb] = cur; open.push(nb);
        } else if (algo === 'dfs') {
          prev[nb] = cur; dist[nb] = nd; open.push(nb);
        } else if (nd < dist[nb]) {                      // relaxation
          dist[nb] = nd; prev[nb] = cur; open.push(nb);
        } else continue;
        opened.push(nb);
      }
      yield { closed: cur, opened };
    }
    return { found: false, prev };
  }

  function buildPath(prev, start, end) {
    const p = []; let c = end;
    while (c !== -1 && c !== start) { p.push(c); c = prev[c]; }
    if (c !== start) return null;
    p.push(start);
    return p.reverse();
  }

  function pathCost(path, cols) {
    let t = 0;
    for (let k = 1; k < path.length; k++) {
      const a = path[k - 1], b = path[k];
      t += (a % cols !== b % cols && ((a / cols) | 0) !== ((b / cols) | 0)) ? SQRT2 : 1;
    }
    return t;
  }

  const api = { search, buildPath, pathCost, neighbors, heuristic };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else global.Pathfinding = api;
})(typeof window !== 'undefined' ? window : globalThis);
