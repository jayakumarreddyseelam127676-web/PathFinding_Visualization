/** UI layer: canvas drawing, mouse/touch interaction, animation loop. */
(function () {
  'use strict';
  const COLS = 36, ROWS = 20, N = COLS * ROWS;
  const EMPTY = 0, OPEN = 1, CLOSED = 2, PATH = 3;
  const $ = (id) => document.getElementById(id);
  const canvas = $('board'), ctx = canvas.getContext('2d');

  const INFO = {
    astar: 'A*: f(n) = g(n) + h(n). Uses a heuristic to head toward the goal. Optimal when the heuristic never overestimates; usually explores far fewer nodes than Dijkstra.',
    dijkstra: 'Dijkstra: expands the node with the lowest cost from the start. Guaranteed shortest path, but explores in all directions (no goal guidance).',
    bfs: 'BFS: explores layer by layer using a queue. Shortest path in number of steps on an unweighted grid; explores a lot of cells.',
    dfs: 'DFS: dives deep using a stack. Finds a path if one exists, but the path is usually long and NOT the shortest.',
    greedy: 'Greedy Best-First: always expands the node that looks closest to the goal (by h(n) only). Very fast, but not guaranteed to be optimal.'
  };

  const s = {
    walls: new Uint8Array(N), cells: new Uint8Array(N),
    start: (ROWS >> 1) * COLS + 5, end: (ROWS >> 1) * COLS + COLS - 6,
    gen: null, pathQueue: null, fullPath: null,
    running: false, finished: false, visited: 0, cell: 20, dpr: 1, acc: 0, last: 0
  };

  const cssVar = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  const options = () => ({
    algo: $('algo').value, heuristic: $('heur').value, diagonal: $('diag').checked,
    cols: COLS, rows: ROWS, walls: s.walls, start: s.start, end: s.end
  });

  function resize() {
    s.dpr = window.devicePixelRatio || 1;
    const w = canvas.parentElement.clientWidth - 24;
    s.cell = Math.max(8, Math.floor(w / COLS));
    canvas.style.width = s.cell * COLS + 'px';
    canvas.style.height = s.cell * ROWS + 'px';
    canvas.width = s.cell * COLS * s.dpr;
    canvas.height = s.cell * ROWS * s.dpr;
    draw();
  }

  function draw() {
    const c = s.cell;
    const col = { bg: cssVar('--cell'), grid: cssVar('--grid'), wall: cssVar('--wall'), [OPEN]: cssVar('--front'),
      [CLOSED]: cssVar('--vis'), [PATH]: cssVar('--path'), s: cssVar('--start'), e: cssVar('--end') };
    ctx.setTransform(s.dpr, 0, 0, s.dpr, 0, 0);
    ctx.fillStyle = col.bg; ctx.fillRect(0, 0, c * COLS, c * ROWS);
    for (let i = 0; i < N; i++) {
      const color = s.walls[i] ? col.wall : s.cells[i] ? col[s.cells[i]] : null;
      if (color) { ctx.fillStyle = color; ctx.fillRect((i % COLS) * c, ((i / COLS) | 0) * c, c, c); }
    }
    ctx.strokeStyle = col.grid; ctx.lineWidth = 1; ctx.beginPath();
    for (let x = 0; x <= COLS; x++) { ctx.moveTo(x * c + .5, 0); ctx.lineTo(x * c + .5, ROWS * c); }
    for (let y = 0; y <= ROWS; y++) { ctx.moveTo(0, y * c + .5); ctx.lineTo(COLS * c, y * c + .5); }
    ctx.stroke();
    for (const [i, color, label] of [[s.start, col.s, 'S'], [s.end, col.e, 'E']]) {
      const x = (i % COLS) * c, y = ((i / COLS) | 0) * c;
      ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(x + 2, y + 2, c - 4, c - 4, 4); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.font = 'bold ' + Math.floor(c * .55) + 'px system-ui';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, x + c / 2, y + c / 2 + 1);
    }
  }

  function setStats(len, cost, status) {
    $('sVis').textContent = s.visited;
    $('sLen').textContent = len == null ? '–' : len;
    $('sCost').textContent = cost == null ? '–' : Math.round(cost * 100) / 100;
    $('sStat').textContent = status;
  }

  function applyEvent(ev) {
    s.visited++;
    if (ev.closed !== s.start && ev.closed !== s.end) s.cells[ev.closed] = CLOSED;
    for (const i of ev.opened) if (i !== s.end && s.cells[i] === EMPTY) s.cells[i] = OPEN;
  }

  function clearSearch() {
    s.cells.fill(EMPTY); s.visited = 0; s.gen = null; s.pathQueue = null; s.fullPath = null;
    s.running = false; s.finished = false; setStats(null, null, 'Ready'); draw();
  }

  function startRun() {
    clearSearch();
    s.gen = Pathfinding.search(options()); s.running = true; s.acc = 0; s.last = performance.now();
    $('sStat').textContent = 'Searching…';
    requestAnimationFrame(tick);
  }

  function searchDone(res) {
    s.fullPath = res.found ? Pathfinding.buildPath(res.prev, s.start, s.end) : null;
    if (!s.fullPath) { s.running = false; s.finished = true; setStats(null, null, 'No path'); return; }
    s.pathQueue = s.fullPath.slice();
  }

  function finishPath() {
    s.pathQueue = null; s.running = false; s.finished = true;
    setStats(s.fullPath.length, Pathfinding.pathCost(s.fullPath, COLS), 'Path found');
  }

  function tick(now) {
    if (!s.running) return;
    const sps = $('speed').value ** 2 * .5 + 2; // steps per second
    s.acc += Math.min(now - s.last, 100) * sps / 1000; s.last = now;
    let steps = Math.floor(s.acc); s.acc -= steps;
    while (steps-- > 0 && s.running) {
      if (s.gen) {
        const r = s.gen.next();
        if (r.done) { s.gen = null; searchDone(r.value); } else applyEvent(r.value);
      } else if (s.pathQueue) {
        const i = s.pathQueue.shift();
        if (i !== s.start && i !== s.end) s.cells[i] = PATH;
        if (!s.pathQueue.length) finishPath();
      }
    }
    if (s.running) $('sVis').textContent = s.visited;
    draw();
    if (s.running) requestAnimationFrame(tick);
  }

  /** Run the whole search at once (used when editing after a finished run). */
  function runInstant() {
    s.cells.fill(EMPTY); s.visited = 0;
    const gen = Pathfinding.search(options());
    let r;
    while (!(r = gen.next()).done) applyEvent(r.value);
    s.fullPath = r.value.found ? Pathfinding.buildPath(r.value.prev, s.start, s.end) : null;
    s.finished = true;
    if (!s.fullPath) setStats(null, null, 'No path');
    else {
      for (const i of s.fullPath) if (i !== s.start && i !== s.end) s.cells[i] = PATH;
      setStats(s.fullPath.length, Pathfinding.pathCost(s.fullPath, COLS), 'Path found');
    }
    draw();
  }
  const refresh = () => (s.finished ? runInstant() : draw());

  // ---- interaction ----
  let drag = null, paint = 1;
  function cellAt(e) {
    const r = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - r.left) / s.cell), y = Math.floor((e.clientY - r.top) / s.cell);
    return x < 0 || y < 0 || x >= COLS || y >= ROWS ? -1 : y * COLS + x;
  }
  canvas.addEventListener('pointerdown', (e) => {
    const i = cellAt(e); if (i < 0) return;
    if (s.running) { clearSearch(); $('sStat').textContent = 'Stopped'; }
    canvas.setPointerCapture(e.pointerId);
    if (i === s.start) drag = 'S';
    else if (i === s.end) drag = 'E';
    else { drag = 'W'; paint = s.walls[i] ? 0 : 1; s.walls[i] = paint; refresh(); }
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const i = cellAt(e); if (i < 0) return;
    if (drag === 'W') {
      if (i !== s.start && i !== s.end && s.walls[i] !== paint) { s.walls[i] = paint; refresh(); }
    } else if (i !== s.start && i !== s.end && !s.walls[i]) {
      if (drag === 'S') s.start = i; else s.end = i;
      if (s.finished) runInstant(); else { s.cells.fill(EMPTY); draw(); }
    }
  });
  canvas.addEventListener('pointerup', () => (drag = null));

  $('run').onclick = startRun;
  $('stop').onclick = () => { s.running = false; $('sStat').textContent = 'Stopped'; };
  $('clearPath').onclick = clearSearch;
  $('clearAll').onclick = () => { s.walls.fill(0); clearSearch(); };
  $('maze').onclick = () => {
    s.walls.fill(0);
    for (let i = 0; i < N; i++) if (i !== s.start && i !== s.end && Math.random() < .28) s.walls[i] = 1;
    clearSearch();
  };
  const onChange = () => { if (s.finished) runInstant(); };
  $('algo').onchange = () => {
    const a = $('algo').value;
    $('info').textContent = INFO[a];
    $('heur').disabled = !['astar', 'greedy'].includes(a);
    onChange();
  };
  $('heur').onchange = onChange;
  $('diag').onchange = onChange;
  window.addEventListener('resize', resize);
  matchMedia('(prefers-color-scheme:dark)').addEventListener('change', draw);
  $('algo').onchange(); resize();
})();
