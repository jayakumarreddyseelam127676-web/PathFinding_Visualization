const test = require('node:test');
const assert = require('node:assert');
const P = require('../js/algorithms.js');

function run(algo, o = {}) {
  const cols = o.cols || 5, rows = o.rows || 5;
  const opts = { algo, cols, rows, walls: o.walls || new Uint8Array(cols * rows),
    start: o.start ?? 0, end: o.end ?? cols * rows - 1, diagonal: !!o.diagonal, heuristic: 'manhattan' };
  const g = P.search(opts); let r;
  while (!(r = g.next()).done);
  const path = r.value.found ? P.buildPath(r.value.prev, opts.start, opts.end) : null;
  return { found: r.value.found, path, cols };
}

test('all algorithms find a path on an empty grid', () => {
  for (const a of ['bfs', 'dfs', 'dijkstra', 'astar', 'greedy']) assert.ok(run(a).found, a);
});
test('BFS, Dijkstra and A* give the optimal length (9 cells)', () => {
  for (const a of ['bfs', 'dijkstra', 'astar']) assert.strictEqual(run(a).path.length, 9, a);
});
test('diagonal moves reduce the cost to 4*sqrt(2)', () => {
  const r = run('astar', { diagonal: true });
  assert.ok(Math.abs(P.pathCost(r.path, r.cols) - 4 * Math.SQRT2) < 1e-9);
});
test('returns no path when the end is walled off', () => {
  const walls = new Uint8Array(25); [23, 19].forEach((i) => (walls[i] = 1));
  for (const a of ['bfs', 'dfs', 'dijkstra', 'astar', 'greedy']) assert.strictEqual(run(a, { walls }).found, false, a);
});
test('A* matches Dijkstra cost on a random maze', () => {
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const cols = 20, rows = 12, walls = new Uint8Array(cols * rows);
  for (let i = 1; i < walls.length - 1; i++) if (rnd() < 0.25) walls[i] = 1;
  const a = run('astar', { cols, rows, walls, diagonal: true }), d = run('dijkstra', { cols, rows, walls, diagonal: true });
  assert.strictEqual(a.found, d.found);
  if (a.found) assert.ok(Math.abs(P.pathCost(a.path, cols) - P.pathCost(d.path, cols)) < 1e-9);
});
